package cn.itcast.wanxintx.ensuredemo.bank2;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnsureBank2Service {

	public static void main(String[] args) {
		SpringApplication.run(EnsureBank2Service.class, args);
	}

}
