package cn.itcast.wanxintx.ensuredemo.bank1;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnsureBank1Service {

	public static void main(String[] args) {
		SpringApplication.run(EnsureBank1Service.class, args);
	}

}
