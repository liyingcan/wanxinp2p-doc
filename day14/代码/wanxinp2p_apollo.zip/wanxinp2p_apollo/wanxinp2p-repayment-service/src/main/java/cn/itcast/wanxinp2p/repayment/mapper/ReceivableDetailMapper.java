package cn.itcast.wanxinp2p.repayment.mapper;

import cn.itcast.wanxinp2p.repayment.entity.ReceivableDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 操作receivable_detail的Mapper接口
 */
public interface ReceivableDetailMapper extends BaseMapper<ReceivableDetail> {
}
