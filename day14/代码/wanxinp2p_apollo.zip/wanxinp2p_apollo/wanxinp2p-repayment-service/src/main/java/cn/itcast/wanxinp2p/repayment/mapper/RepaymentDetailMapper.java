package cn.itcast.wanxinp2p.repayment.mapper;

import cn.itcast.wanxinp2p.repayment.entity.RepaymentDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * 操作repayment_detail表的mapper接口
 */
public interface RepaymentDetailMapper extends BaseMapper<RepaymentDetail> {

}
