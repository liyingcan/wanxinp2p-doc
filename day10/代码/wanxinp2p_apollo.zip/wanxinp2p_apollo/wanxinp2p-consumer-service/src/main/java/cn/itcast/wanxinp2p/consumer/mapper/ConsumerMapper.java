package cn.itcast.wanxinp2p.consumer.mapper;

import cn.itcast.wanxinp2p.consumer.entity.Consumer;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface ConsumerMapper extends BaseMapper<Consumer> {

}
