package cn.itcast.wanxinp2p.consumer.common.constant;

/**
 * <P>
 * 异步通知结果枚举
 * </p>
 */
public enum NotifyResultCode {

	SUCCESS("00000", "成功"),
	;

	private String code;
	private String desc;

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}

	NotifyResultCode(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}
}
