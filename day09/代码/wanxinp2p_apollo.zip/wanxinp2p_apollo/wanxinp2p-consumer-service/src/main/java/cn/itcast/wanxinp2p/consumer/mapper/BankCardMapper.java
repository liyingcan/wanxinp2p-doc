package cn.itcast.wanxinp2p.consumer.mapper;

import cn.itcast.wanxinp2p.consumer.entity.BankCard;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface BankCardMapper extends BaseMapper<BankCard> {
}
