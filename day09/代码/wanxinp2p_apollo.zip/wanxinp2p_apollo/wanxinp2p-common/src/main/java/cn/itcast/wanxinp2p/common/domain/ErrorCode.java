package cn.itcast.wanxinp2p.common.domain;

public interface ErrorCode {

    int getCode();

    String getDesc();

}
