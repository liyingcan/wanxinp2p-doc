package com.itheima.dbsharding.shardingjdbcdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShardingJdbcDemoBootstrap {

    public static void main(String[] args) {
        SpringApplication.run(ShardingJdbcDemoBootstrap.class, args);
    }

}
