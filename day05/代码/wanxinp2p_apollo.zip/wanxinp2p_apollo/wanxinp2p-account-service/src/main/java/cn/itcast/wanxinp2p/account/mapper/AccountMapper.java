package cn.itcast.wanxinp2p.account.mapper;


import cn.itcast.wanxinp2p.account.entity.Account;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

public interface AccountMapper extends BaseMapper<Account> {

}
